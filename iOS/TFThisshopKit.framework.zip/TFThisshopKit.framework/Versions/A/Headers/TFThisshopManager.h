//
//  TFThisshopManager.h
//
//  Created by Ricky on 2020/12/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

///Delegate
@protocol TFThisshopManagerDelegate <NSObject>

//充值成功回调
-(void)thisshopRechargeSuccessedWithOrderId:(NSString*)orderId;

//充值失败回调
-(void)thisshopRechargeFailedWithOrderId:(NSString*)orderId;;

@end



@interface TFThisshopManager : NSObject


@property (nonatomic, copy) NSString * TFAppId;
@property (nonatomic, copy) NSString * TFAppKey;

@property (nonatomic, weak) id<TFThisshopManagerDelegate> delegate;



+ (instancetype)sharedInstance;

/**
 跳转充值
 
 @param orderId 订单流水号
 @param productId 商品Id
 @param count 充值数量
 @param successed 验证appId成功
 @param failed 验证appId失败
 */
-(void)startRechargeWithOrderId:(NSString*)orderId andProductId:(NSString*)productId andCount:(NSString*)count andSuccessed:(void (^)(NSDictionary *data))successed andFailed:(void (^)(NSError * error))failed;

//回调处理
- (void)handleOpenURL:(NSURL *)aURL;



@end

NS_ASSUME_NONNULL_END
